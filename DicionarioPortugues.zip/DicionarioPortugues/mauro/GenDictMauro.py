import glob
import os.path
import re
from bs4 import BeautifulSoup

from DicionarioPortugues.tools import EnoLex as enolex

ID_WORD = 'data-toggle-header'

CLASS_POS = 'qualifica'

DIR = '/home/ferris/Documents/dict/html/mauro'
HEADER = 'dict=De Mauro\n'
OUT = 'mauro.dict'
LOG = 'GenDict.log'

TEST_FILE = '/home/ferris/Documents/dict/html/mauro/pacifista'
# TEST_FILE = '/home/ferris/Documents/dict/html/test.html'


def add_log(message: str):
    with open(LOG, 'a') as log_file:
        log_file.write(message + '\n')


def read_html(html_file: str):
    with open(html_file, 'r') as f:
        key = ''
        entry_text = ''
        soup = BeautifulSoup(f, features="lxml")
        # word
        word_container = soup.find('h1', attrs={'data-toggle-header': ''})
        word_numbering = ''
        word_text = ''
        word = ''

        for child in word_container.children:
            if child.name == 'sup':
                word_numbering = f' ({child.text})'
            elif not child.text.isspace():
                word_text = child.text

        key = word_text
        word = word_text + word_numbering
        # except AttributeError:
        #     message = f'word_container not found in {html_file}\n'
        #     add_log(message)

        entry_text += enolex.new_prop('key', key)
        entry_text += enolex.new_prop('word', word)

        ipa_and_ety = soup.findAll('section', attrs={'id': 'lemma_lemma'})

        # pos
        pos = soup.find('span', attrs={'class': 'qualifica'})
        if pos:
            entry_text += enolex.new_prop('pos', pos)

        if ipa_and_ety:
            # ipa
            ipa = ipa_and_ety[0].text.strip()
            entry_text += enolex.new_prop('ipa', ipa)

            if len(ipa_and_ety) >= 2:
                # etymology
                ety = ipa_and_ety[1].text.strip()
                entry_text += enolex.new_prop('ety', ety)

        # definitions
        section = soup.find('section', attrs={'id': 'descrizione'})
        current_number = 0
        try:
            for child in section.children:
                if child.name == 'span' and child.has_attr('class'):
                    if child['class'][0] == 'ac':
                        found_number = enolex.get_numbers(child.text)
                        if current_number < found_number:
                            entry_text += enolex.DEFINITION_GROUP
                            current_number = found_number
                        entry_text += '\ndef='
                    elif child['class'][0] == 'mu':
                        continue
                elif child.name == 'i':
                    entry_text += child.__str__()
                else:
                    entry_text += child.text.strip()
        except AttributeError:
            message = f'<section class="descrizione"> not found in {html_file}\n'
            add_log(message)

        # Polirematiche
        poli = soup.find('section', attrs={'id': 'polirematiche'})

        if poli:
            com = ''

            for child in poli.children:
                # skip the subtitle
                if child.name == 'h4':
                    continue
                elif child.name == 'strong':
                    com += f'\ncom={child.text}\ndes='
                elif child.name == 'br' and com[-1] != '=':
                    com += enolex.NEW_LINE
                else:
                    com += child.text

            entry_text += com.strip()

        # end of entry
        entry_text += enolex.END_OF_ENTRY

        return enolex.Entry(key, entry_text)


def process_all_files():
    file_list = glob.glob(f'{DIR}/*')
    entries = []
    total = len(file_list)
    for i in range(total):
        print('\r', f'progress: {i}/{total}', end='')
        entries.append(read_html(file_list[i]))

    entries.sort(key=lambda x: x.key)

    with open(OUT, 'w') as f:
        f.write(HEADER)
        for entry in entries:
            f.write(entry.text)


def test():
    entry = read_html(TEST_FILE)
    print(entry.text)


def main():
    # process_all_files()
    test()


if __name__ == "__main__":
    main()
