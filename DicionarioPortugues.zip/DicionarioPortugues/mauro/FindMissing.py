URLS = 'urls'
SCRAPED = 'scrapy_output'
MISSING = 'missing'


def main():
    urls = []
    scraped = []
    missing = []

    with open(URLS, 'r') as ufile:
        urls = list(set(ufile.readlines()))

    with open(SCRAPED, 'r') as sfile:
        scraped = sfile.readlines()

    i = 0
    missing = 0
    while i < len(urls):
        print('\r', f'progress: {i}/{len(urls)}, found {missing} missing urls', end='')
        j = 0
        found = False
        while j < len(scraped):
            if urls[i].strip() in scraped[j]:
                urls.pop(i)
                scraped.pop(j)
                found = True
                break
            j += 1

        if not found:
            missing += 1
            i += 1

    with open(MISSING, 'w') as mfile:
        mfile.writelines(urls)


if __name__ == "__main__":
    main()
