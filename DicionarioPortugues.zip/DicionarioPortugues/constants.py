INFOPEDIA_VERB = 'https://www.infopedia.pt/dicionarios/verbos-portugueses/'
INFOPEDIA_DICT = 'https://www.infopedia.pt/dicionarios/lingua-portuguesa/'

PRIBERAM_DICT = 'https://dicionario.priberam.org/'